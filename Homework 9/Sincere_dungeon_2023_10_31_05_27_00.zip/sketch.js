function setup() {
  createCanvas(300, 500);
}

function draw() {
  background(150);
  line(130,400, 30,350);
    rect(90,300,130,200);
  circle(150,225,225);
   circle(130,200,20);
  circle(170,200,20);
  text('Sam Chaves', 125, 30)
  triangle(90, 240, 200, 250, 125, 260);
point(130,200);
point(170,200);
  line(200,400, 290,350);
  
}
